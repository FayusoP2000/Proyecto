<?php
	session_start();
	error_reporting(0);
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <title>TODOCHOLLOS - Los mejores chollos</title>
    <link rel="shortcut icon" href="images/logo1.jpg" />
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>

</head>

<body>
    <header class="header theme-sky-dark in-line" id="header">
        <div class="in-line">
            <img class="branding-logo"
                 src="images/logo1.jpg"
                 aria-hidden="true" />
            <p class="branding">TODOCHOLLOS - Los mejores chollos</p>
        </div>

		<div>
  <a href="<?php echo isset($_SESSION['usuario']) ? './cerrar.php' : './login.php'; ?>">
    <button type="button" class="btn-cart in-line button button-simple-empty">
      <i class="fas fa-user cart-icon" aria-hidden="true" aria-live="polite"></i>
      <div class="cart-text">
        <?php
          if (isset($_SESSION['usuario'])) {
            	echo '<p style="color:white;">Cerrar sesión<span class="cart-qty"></span></p>';
          } else {
 	          	echo '<p style="color:white;">Iniciar sesión<span class="cart-qty"></span></p>';
          }
        ?>
      </div>
    </button>
  </a>
</div>
    </header>
    <section class="banner  in-stack">
        <div>
            <img class="banner-img" 
                 src="images/logo2.png"
                 aria-hidden="true"
                 width="1400" height="400" />
        </div>
    </section>
    <main id="shop">
                <form>
                    <div class="filters-search-container">
                        <div>
                            <h1><b>LOS CHOLLAZOS DEL DÍA</b></h1>
                        </div>
                    </div>
            <section class="products-container ">
                <div class="products-list in-grid">

                     <div class="products-list in-grid">

                    <article class="product"
                             data-id="0"
                             data-name="Producto1"
                             data-category="celulares"
                             data-price="22499"
                             data-image="images/1.jpg"
                             data-review="3">

                        <div class="product-img-container in-line">
                            <img src="images/1.jpg" class="product-img" />
                        </div>

                        <div class="product-content in-stack">
                            <h2 class="product-name" id="Parse name 1">Producto1</h2>
                            <p class="product-price" id="Parse price 1">Precio1</p>
							<del style="color:#FF0000" class="product-price" id="Parse old_price 1">Precioo1</del>
                            <div>
<?php
if (isset($_SESSION['usuario'])) {
?>

                            <div>
    <button class="button button-simple-solid button-add-to-cart" id="Parse link 1" onclick="window.location.href='https://www.amazon.es/'">
                                        Ir al chollo
    </button>
                            </div>
<?php
}else{
echo '<br>';
echo '<br>Tienes que registrarte para acceder al descuento';
}
?>

                        </div>

                    </article>
                    <article class="product"
                             data-id="1"
                             data-name="Producto2"
                             data-category="consolas"
                             data-price="59999"
                             data-image="images/2.jpg"
                             data-review="5">

                        <div class="product-img-container in-line">
                            <img src="images/2.jpg" class="product-img" />
                        </div>

                        <div class="product-content in-stack">
                            <h2 class="product-name" id="Parse name 2">Producto2</h2>
                            <p class="product-price" id="Parse price 2">Precio2</p>
                            <del style="color:#FF0000" class="product-price" id="Parse old_price 2">Precioo2</del>
                            <div>
<?php
if (isset($_SESSION['usuario'])) {
?>

                            <div>
    <button class="button button-simple-solid button-add-to-cart" id="Parse link 2" onclick="window.location.href='http://amazon.es'">
                                        Ir al chollo
    </button>
                            </div>
<?php
}else{
echo '<br>';
echo '<br>Tienes que registrarte para acceder al descuento';
}
?>

                        </div>

                    </article>
                    <article class="product"
                             data-id="2"
                             data-name="Producto3"
                             data-category="camaras"
                             data-price="54999"
                             data-image="images/3.jpg"
                             data-review="2">
                        <div class="product-img-container in-line">
                            <img src="images/3.jpg" class="product-img" />
                        </div>

                        <div class="product-content in-stack">
                            <h2 class="product-name" id="Parse name 3">Producto3</h2>
                            <p class="product-price" id="Parse price 3">Precio3</p>
                            <del style="color:#FF0000" class="product-price" id="Parse old_price 3">Precioo3</del>
                            <div>
<?php
if (isset($_SESSION['usuario'])) {
?>

                            <div>
    <button class="button button-simple-solid button-add-to-cart" id="Parse link 3" onclick="window.location.href='http://amazon.es'">
                                        Ir al chollo
    </button>
                            </div>
<?php
}else{
echo '<br>';
echo '<br>Tienes que registrarte para acceder al descuento';
}
?>

                        </div>

                        </div>
                    </article>
                    <article class="product"
                             data-id="3"
                             data-name="Producto4"
                             data-category="accesorios"
                             data-price="24999"
                             data-image="images/4.jpg"
                             data-review="3">
                        <div class="product-img-container in-line">
                            <img src="images/4.jpg" class="product-img" />
                        </div>

                        <div class="product-content in-stack">
                            <h2 class="product-name" id="Parse name 4">Producto4</h2>
                            <p class="product-price" id="Parse price 4">Precio4</p>
                            <del style="color:#FF0000" class="product-price" id="Parse old_price 4">Precioo4</del>
                            <div>
<?php
if (isset($_SESSION['usuario'])) {
?>

                            <div>
    <button class="button button-simple-solid button-add-to-cart" id="Parse link 4" onclick="window.location.href='http://amazon.es'">
                                        Ir al chollo
    </button>
                            </div>
<?php
}else{
echo '<br>';
echo '<br>Tienes que registrarte para acceder al descuento';
}
?>

                        </div>
                    </article>
                    <article class="product"
                             data-id="4"
                             data-name="Producto5"
                             data-category="consolas"
                             data-price="46999"
                             data-image="images/5.jpg"
                             data-review="5">
                        <div class="product-img-container in-line">
                            <img src="images/5.jpg" class="product-img" />
                        </div>

                        <div class="product-content in-stack">
                            <h2 class="product-name" id="Parse name 5">Producto5</h2>
                            <p class="product-price" id="Parse price 5">Precio5</p>
                            <del style="color:#FF0000" class="product-price" id="Parse old_price 5">Precio5</del>
                            <div>
<?php
if (isset($_SESSION['usuario'])) {
?>

                            <div>
    <button class="button button-simple-solid button-add-to-cart" id="Parse link 5" onclick="window.location.href='http://amazon.es'">
                                        Ir al chollo
    </button>
                            </div>
<?php
}else{
echo '<br>';
echo '<br>Tienes que registrarte para acceder al descuento';
}
?>

                        </div>
                    </article>
                    <article class="product"
                             data-id="5"
                             data-name="Producto6"
                             data-category="notebooks"
                             data-price="32999"
                             data-image="images/6.jpg"
                             data-review="1">
                        <div class="product-img-container in-line">
                            <img src="images/6.jpg" class="product-img" />
                        </div>

                        <div class="product-content in-stack">
                            <h2 class="product-name" id="Parse name 6">Producto6</h2>
                            <p class="product-price" id="Parse price 6">Precio6</p>
                            <del style="color:#FF0000" class="product-price" id="Parse old_price 6">Precioo6</del>
                            <div>
<?php
if (isset($_SESSION['usuario'])) {
?>

                            <div>
    <button class="button button-simple-solid button-add-to-cart" id="Parse link 6" onclick="window.location.href='http://amazon.es'">
                                        Ir al chollo
    </button>
                            </div>
<?php
}else{
echo '<br>';
echo '<br>Tienes que registrarte para acceder al descuento';
}
?>

                        </div>
                    </article>
                    <article class="product"
                             data-id="6"
                             data-name="Producto7"
                             data-category="notebooks"
                             data-price="37999"
                             data-image="images/7.jpg"
                             data-review="3">
                        <div class="product-img-container in-line">
                            <img src="images/7.jpg" class="product-img" />
                        </div>

                        <div class="product-content in-stack">
                            <h2 class="product-name" id="Parse name 7">Producto7</h2>
                            <p class="product-price" id="Parse price 7">Precio7</p>
                            <del style="color:#FF0000" class="product-price" id="Parse old_price 7">Precioo7</del>
                            <div>
<?php
if (isset($_SESSION['usuario'])) {
?>

                            <div>
    <button class="button button-simple-solid button-add-to-cart" id="Parse link 7" onclick="window.location.href='http://amazon.es'">
                                        Ir al chollo
    </button>
                            </div>
<?php
}else{
echo '<br>';
echo '<br>Tienes que registrarte para acceder al descuento';
}
?>

                        </div>
                    </article>
                    <article class="product"
                             data-id="7"
                             data-name="Producto8"
                             data-category="accesorios"
                             data-price="11999"
                             data-image="images/8.jpg"
                             data-review="2">
                        <div class="product-img-container in-line">
                            <img src="images/8.jpg" class="product-img" />
                        </div>

                        <div class="product-content in-stack">
                            <h2 class="product-name" id="Parse name 8">Producto8</h2>
                            <p class="product-price" id="Parse price 8">Precio8</p>
                            <del style="color:#FF0000" class="product-price" id="Parse old_price 8">Precioo8</del>
                            <div>
<?php
if (isset($_SESSION['usuario'])) {
?>

                            <div>
    <button class="button button-simple-solid button-add-to-cart" id="Parse link 8" onclick="window.location.href='http://amazon.es'">
                                        Ir al chollo
    </button>
                            </div>
<?php
}else{
echo '<br>';
echo '<br>Tienes que registrarte para acceder al descuento';
}
?>

                        </div>
                    </article>
                    <article class="product"
                             data-id="8"
                             data-name="Producto9"
                             data-category="notebooks"
                             data-price="119999"
                             data-image="images/9.jpg"
                             data-review="4">
                        <div class="product-img-container in-line">
                            <img src="images/9.jpg" class="product-img" />
                        </div>

                        <div class="product-content in-stack">
                            <h2 class="product-name" id="Parse name 9">Producto9</h2>
                            <p class="product-price" id="Parse price 9">Precio9</p>
                            <del style="color:#FF0000" class="product-price" id="Parse old_price 9">Precioo9</del>
                            <div>
<?php
if (isset($_SESSION['usuario'])) {
?>

                            <div>
    <button class="button button-simple-solid button-add-to-cart" id="Parse link 9" onclick="window.location.href='http://amazon.es'">
                                        Ir al chollo
    </button>
                            </div>
<?php
}else{
echo '<br>';
echo '<br>Tienes que registrarte para acceder al descuento';
}
?>
                        </div>
                    </article>
                    <article class="product"
                             data-id="9"
                             data-name="Producto10"
                             data-category="celulares"
                             data-price="79999"
                             data-image="images/10.jpg"
                             data-review="3">
                        <div class="product-img-container in-line">
                            <img src="images/10.jpg" class="product-img" />
                        </div>

                        <div class="product-content in-stack">
                            <h2 class="product-name" id="Parse name 10">Producto10</h2>
                            <p class="product-price" id="Parse price 10">Precio10</p>
                            <del style="color:#FF0000" class="product-price" id="Parse old_price 10">Precioo10</del>
                            <div>
<?php
if (isset($_SESSION['usuario'])) {
?>

                            <div>
    <button class="button button-simple-solid button-add-to-cart" id="Parse link 10" onclick="window.location.href=\"http://amazon.es\"">
                                        Ir al chollo
    </button>
                            </div>
<?php
}else{
echo '<br>';
echo '<br>Tienes que registrarte para acceder al descuento';
}
?>

                        </div>
                    </article>
                    <article class="product"
                             data-id="10"
                             data-name="Producto11"
                             data-category="consolas"
                             data-price=<?php echo "0000"; ?>
                             data-image="images/11.jpg"
                             data-review="4">
                        <div class="product-img-container in-line">
                            <img src="images/11.jpg" class="product-img" />
                        </div>

                        <div class="product-content in-stack">
                            <h2 class="product-name" id="Parse name 11">Producto11</h2>
                            <p class="product-price" id="Parse price 11">Precio11</p>
                            <del style="color:#FF0000" class="product-price" id="Parse old_price 11">Precioo11</del>
                            <div>
<?php
if (isset($_SESSION['usuario'])) {
?>

                            <div>
    <button class="button button-simple-solid button-add-to-cart" id="Parse link 11" onclick="window.location.href='http://amazon.es'">
                                        Ir al chollo
    </button>
                            </div>
<?php
}else{
echo '<br>';
echo '<br>Tienes que registrarte para acceder al descuento';
}
?>
                            </div>
                        </div>
                    </article>
                    <article class="product"
                             data-id="11"
                             data-name="Producto12"
                             data-category="accesorios"
                             data-price="4999"
                             data-image="images/12.jpg"
                             data-review="5">
                        <div class="product-img-container in-line">
                            <img src="images/12.jpg"
                                 class="product-img" />
                        </div>

                        <div class="product-content in-stack">
                            <h2 class="product-name" id="Parse name 12">Producto12</h2>
                            <p class="product-price" id="Parse price 12">Precio12</p>
                            <del style="color:#FF0000" class="product-price" id="Parse old_price 12">Precioo12</del>
                            <div>
<?php
if (isset($_SESSION['usuario'])) {
?>

                            <div>
    <button class="button button-simple-solid button-add-to-cart" id="Parse link 12" onclick="window.location.href='http://amazon.es'">
                                        Ir al chollo
    </button>
                            </div>
<?php
}else{
echo '<br>';
echo '<br>Tienes que registrarte para acceder al descuento';
}
?>
                            </div>
                        </div>

                    </article>
            </section>

    </main>
    <footer class="footer-main in-line theme-sky-dark">
        <div class="logo-container in-line">
            <img src="images/logo1.jpg"
                 class="logo" />
            <p>TODOCHOLLOS - Los mejores chollos</p>
        </div>
    </footer>
        <script src="index.js"></script>

</body>

</html>
