<?php
	session_start();
	error_reporting(0);
	unset($_SESSION['usuario']);
	session_destroy();
	header("location:index.php");
?>
