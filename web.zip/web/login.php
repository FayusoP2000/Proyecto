<?php
	session_start();
	error_reporting(0);

	$servername = "localhost";
	$username = "root";
	$password = "110400";
	$dbname = "todochollos";

	$conn = mysqli_connect($servername, $username, $password, $dbname);

	if ($conn) {
		if (isset($_SESSION['usuario'])) {
			header("location:index.php");
		}
?>
		<!DOCTYPE html>
		<html lang="es" >
		<head>
		  <meta charset="UTF-8">
		  <title>TODOCHOLLOS</title>
		  <link rel="shortcut icon" href="images/logo1.jpg"/>
		  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
		<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900'>
		<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Montserrat:400,700'>
		<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'><link rel="stylesheet" href="./style.css">

		</head>
		<body>

		<div class="container">
		  <div class="info">
		    <h1>TODOCHOLLOS - Los mejores chollos</h1>
		  </div>
		</div>
		<div class="form">
		  <div class="thumbnail"><img src="./images/logo1.jpg"/></div>
		  <form class="register-form" method="POST">
		    <input type="text" placeholder="Usuario" name="username"/>
		    <input type="password" placeholder="Contraseña" name="password"/>
		    <input type="email" placeholder="Email" name="email"/>
		    <button>Registrar</button>
		    <p class="message">¿Ya estas registrado? <a href="#">Inicia Sesión</a></p>
		  </form>
		  <form class="login-form" method="POST">
		    <input type="text" placeholder="Usuario" name="user"/>
		    <input type="password" placeholder="Contraseña" name="pass"/>
		    <button>Iniciar Sesión</button>
		    <p class="message">¿No tienes una cuenta? <a href="#">Crear una cuenta</a></p>
		  </form>
		</div>
		<!-- partial -->
		  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script><script  src="./script.js"></script>

		</body>
		</html>
<?php

		if (isset($_POST['user']) && isset($_POST['pass'])) {
			$user = $_POST['user'];
			$pass = $_POST['pass'];

			$sql = "SELECT * FROM users WHERE username = '$user' AND password = '$pass'";

			$result = mysqli_query($conn, $sql);

			if (mysqli_num_rows($result) > 0) {
				echo "<p class='green'>[+] Usuario y Contraseña Validos </p>";

				while ($row = mysqli_fetch_assoc($result)) {
					$_SESSION['usuario'] = $row['username'];

					echo "<script>window.location.href='index.php';</script>";
				}

			} else {
				echo "<p class='red'> [ ! ] Usuario $user y contraseña $pass incorrectos <br><br> </p>" . mysqli_error($conn);
			}
		}
		if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['email'])) {
			$user = $_POST['username'];
			$pass = $_POST['password'];
			$email = $_POST['email'];

			$sql = "SELECT username from users where username = '$user';";
			$result = mysqli_query($conn, $sql);
			if (mysqli_num_rows($result) == 0) {

				$sql = "INSERT INTO users (username, password, email) VALUES ('$user', '$pass', '$email');";

				if (mysqli_query($conn, $sql)) {
					echo "<p class='green'>[✔] Usuario registrado satisfactoriamente <br></p>";
				} else {
					echo "<p class='red'>[x] El usuario no se ha podido crear : </p>" . mysqli_error($conn) . "<br>";
				}

			} else {
				echo "<p class='red'> [*] El usuario ya existe <br> </p>";
			}
		}
		mysqli_close($conn);
	} else {
		echo "[!] No se ha podido conectar con la BBDB";
	}

?>
