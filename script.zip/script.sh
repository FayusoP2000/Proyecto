#!/bin/bash

#Autor: Fernando Ayuso Perez
#Description:

#Colours
greenColor="\e[0;32m\033[1m"
endColor="\033[0m\e[0m"
redColor="\e[0;31m\033[1m"
blueColor="\e[0;34m\033[1m"
yellowColor="\e[0;33m\033[1m"
purpleColor="\e[0;35m\033[1m"
turquoiseColor="\e[0;36m\033[1m"
grayColor="\e[0;37m\033[1m"

#VARS
prompt=$(echo -e "\t${redColor}$(whoami)@$(hostnamectl | head -n1 | xargs |cut -d' ' -f3) #${endColor}  ${grayColor}$0 ${endColor}")
web="/var/www/html/a"

trap ctrl_c INT

function ctrl_c() {
	echo -e "\n\n\t${redColor}[*] Saliendo....${endColor}"
	tput cnorm
	exit 1
}

clear
echo -e "\t${purpleColor} _____          _         ___ _           _ _            ${endColor}"
echo -e "\t${purpleColor}/__   \___   __| | ___   / __\ |__   ___ | | | ___  ___  ${endColor}"
echo -e "\t${purpleColor}  / /\/ _ \ / _\` |/ _ \ / /  | '_ \ / _ \| | |/ _ \/ __| ${endColor}"
echo -e "\t${purpleColor} / / | (_) | (_| | (_) / /___| | | | (_) | | | (_) \__ \ ${endColor}"
echo -e "\t${purpleColor} \/   \___/ \__,_|\___/\____/|_| |_|\___/|_|_|\___/|___/ ${endColor}"

echo -e "\n"
echo -e "\t${turquoiseColor}Instrucciones de uso:${endColor}\n"
echo -e "\t\t${yellowColor}[*]${endColor} ${grayColor}$0 (opción)${endColor}\n"
echo -e "\t\t    ${purpleColor}1)${endColor}  ${grayColor}Recopilación de productos y almacenaje en la BBDD${endColor}"
echo -e "\t\t    ${purpleColor}2)${endColor}  ${grayColor}Actualización instantánea de la página${endColor}"
echo -e "\t\t    ${purpleColor}3)${endColor}  ${grayColor}Configurar rango de actualización de la página${endColor}"
echo -e "\t\t    ${purpleColor}4)${endColor}  ${grayColor}Backup instantánea${endColor}"
echo -e "\t\t    ${purpleColor}5)${endColor}  ${grayColor}Salir${endColor}\n"

read -p "$prompt" opcion

case $opcion in
	1)
	tput civis
	echo -e "\n\t${grayColor}[${purpleColor}*${endColor}${grayColor}]${endColor}  ${grayColor}Recolectando chollos . . .${endColor}\n"
	#Sacamos los chollos de los generos más solicitados (teles, móviles) y obtenemos 3 enlaces por categoría
	echo "" > urls.txt
#	curl -s 'https://www.amazon.es/deal/60d10a48' -H "Accept-Charset: UTF-8" -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36' | grep -oP "\/dp\/.*\?" | tr -d '?' | sort -u | head -n3 | awk '{print "https://www.amazon.es"$1}' >> urls.txt
#	curl -s 'https://www.amazon.es/deal/e28bd8f0' -H "Accept-Charset: UTF-8" -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36' | grep -oP "\/dp\/.*\?" | tr -d '?' | sort -u | head -n3 | awk '{print "https://www.amazon.es"$1}' >> urls.txt
#	curl -s 'https://www.amazon.es/deal/bfa32613' -H "Accept-Charset: UTF-8" -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36' | grep -oP "\/dp\/.*\?" | tr -d '?' | sort -u | head -n3 | awk '{print "https://www.amazon.es"$1}' >> urls.txt
#	curl -s 'https://www.amazon.es/deal/f53d628f' -H "Accept-Charset: UTF-8" -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36' | grep -oP "\/dp\/.*\?" | tr -d '?' | sort -u | head -n3 | awk '{print "https://www.amazon.es"$1}' >> urls.txt
	curl -s 'https://www.amazon.es/deal/ddd24858' -H "Accept-Charset: UTF-8" -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36' | grep -oP "\/dp\/.*\?" | tr -d '?' | sort -u | head -n3 | awk '{print "https://www.amazon.es"$1}' >> urls.txt
	curl -s 'https://www.amazon.es/deal/ca736f64' -H "Accept-Charset: UTF-8" -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36' | grep -oP "\/dp\/.*\?" | tr -d '?' | sort -u | head -n3 | awk '{print "https://www.amazon.es"$1}' >> urls.txt
	curl -s 'https://www.amazon.es/deal/980ab6b5' -H "Accept-Charset: UTF-8" -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36' | grep -oP "\/dp\/.*\?" | tr -d '?' | sort -u | head -n3 | awk '{print "https://www.amazon.es"$1}' >> urls.txt
	curl -s 'https://www.amazon.es/deal/76e88212' -H "Accept-Charset: UTF-8" -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36' | grep -oP "\/dp\/.*\?" | tr -d '?' | sort -u | head -n3 | awk '{print "https://www.amazon.es"$1}' >> urls.txt

	sed -i '/^$/d' urls.txt

	#Recorremos el txt de urls, yendo de una en una, tirando una petición y generando un txt con el código
	num=1
	cat urls.txt | while read url
	do
		echo $url
		#Por cada web crea un archivo, saca los datos y va a la segunda web...
		#contador para la imagen
		curl -s -H "Accept-Charset: UTF-8" -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36' $url |  sed 's/&#34;/"/g; s/–/-/g; s/”/"/g' | iconv -t UTF-8 > enlace.txt
		price=$(cat enlace.txt | grep -oP "<span class=\"a-offscreen\">.*?</span>" | head -n1 | grep -oP '>.*?<' | tr -d '<>')
		old_price=$(cat enlace.txt | grep -oP "<span aria-hidden=\"true\">\d.*?€</span>" | grep -oP '>.*?<' | tr -d '<>' | head -n1)
		name=$(cat enlace.txt | grep -oP "<span id=\"productTitle\" class=\".*?\">.*?</span>" | grep -oP ">.*<" | tr -d '<>' | awk '{$1=$1}1' | tr -d '&;#')
		#image=$(cat enlace.txt | grep -o "data-old-hires=\".*jpg\"" | grep -oP "\".*?\"" | tr -d '"')
		image=$(cat enlace.txt | grep -oP '<img[^>]*\bsrc="\K[^"]+(?=".*id="landingImage")')
		#Exportarlas a otra ruta y cuando sea necesario actualizar la pagina, copiarlas a imagenes
		wget -q $image -O images/$num.jpg
		mysql -u root -p110400 -e "use todochollos; UPDATE products SET name_products='$name', old_price_products='$old_price', price_products='$price', link_products='$url' WHERE id_products='$num';"
		let num++
	done
	rm -f enlace.txt 2>/dev/null
	rm -f urls.txt 2>/dev/null
	echo -e "\t${grayColor}[${greenColor}+${endColor}${grayColor}]${endColor}  ${grayColor}Chollos almacenados en la BBDD correctamente${endColor}\n"
	tput cnorm
	;;
	2)
	tput civis
    	echo -e "\n\t${grayColor}[${purpleColor}*${endColor}${grayColor}]${endColor}  ${grayColor}Actualizando página . . .${endColor}\n"
	for num in $(seq 1 12) #1 -12
	do
		name=$(mysql -s -u root -p110400 -e "use todochollos; select name_products from  products where id_products = $num" | grep -v '_products' | tr -d '!*[]}{⨪_.,="·#~%<>;/\$' | sed 's/\//\\\//g' | sed 's/º//g')
		price=$(mysql -s -u root -p110400 -e "use todochollos; select price_products from  products where id_products = $num" | grep -v '_products')
		old_price=$(mysql -s -u root -p110400 -e "use todochollos; select old_price_products from  products where id_products = $num" | grep -v '_products')
		link=$(mysql -s -u root -p110400 -e "use todochollos; select link_products from  products where id_products = $num" | grep -v '_products')
		link_tag=$(echo $link |sed 's/\//\\\//g' |awk '{print $1"?tag=todochollos-21"}')

		sed -i "s/id=\"Parse name $num\">.*<\/h2>/id=\"Parse name $num\">$name<\/h2>/gi" $web/index.php
		sed -i "s/id=\"Parse price $num\">.*<\/p>/id=\"Parse price $num\">$price<\/p>/gi" $web/index.php
		sed -i "s/id=\"Parse old_price $num\">.*<\/del>/id=\"Parse old_price $num\">$old_price<\/del>/gi" $web/index.php
		sed -i "s/<a href=\".*\" id=\"Parse link $num\"/<a href=\"$link_tag\" id=\"Parse link $num\"/g" $web/index.php

		cp -f images/$num.jpg $web/images
	done
    echo -e "\t${grayColor}[${greenColor}+${endColor}${grayColor}]${endColor}  ${grayColor}Página actualizada correctamente"
    tput cnorm
	;;
	3)
	text=$(echo -e "\n\t${grayColor}Selecciona una hora de actualización automatica: ")
	read -p "$text" hora
	sed -i "s/0 \*\/[0-9] \* \* \* root \/opt\/crontab\/script.sh/0 \*\/$hora \* \* \* root \/opt\/crontab\/script.sh/g" /etc/crontab
	;;
	4)
	cp -r $web /opt/backup

	;;
	5)
		echo -e "\n\t${redColor}[*]${endColor} ${redColor}Saliendo....${endColor}\n\n"
		exit
	;;
	*)
		echo -e "\t[!] No se ha seleccionado una opcion permitida. Saliendo ..."
		exit
esac
