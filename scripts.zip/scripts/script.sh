#!/bin/bash

#Sacamos los chollos de los generos más solicitados (teles, móviles) y obtenemos 3 enlaces por categoría
echo "" > urls.txt
curl -s 'https://www.amazon.es/deal/a3106d38' -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36' | grep -oP "\/dp\/.*\?" | tr -d '?' | sort -u | head -n3 | awk '{print "https://www.amazon.es"$1}' >> urls.txt
curl -s 'https://www.amazon.es/deal/67a74519' -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36' | grep -oP "\/dp\/.*\?" | tr -d '?' | sort -u | head -n3 | awk '{print "https://www.amazon.es"$1}' >> urls.txt
curl -s 'https://www.amazon.es/deal/f40024c4' -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36' | grep -oP "\/dp\/.*\?" | tr -d '?' | sort -u | head -n3 | awk '{print "https://www.amazon.es"$1}' >> urls.txt
curl -s 'https://www.amazon.es/deal/cfc476a3' -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36' | grep -oP "\/dp\/.*\?" | tr -d '?' | sort -u | head -n3 | awk '{print "https://www.amazon.es"$1}' >> urls.txt
sed -i '/^$/d' urls.txt

#Recorremos el txt de urls, yendo de una en una, tirando una petición y generando un txt con el código
num=1
cat urls.txt | while read url
do
	#Por cada web crea un archivo, saca los datos y va a la segunda web...
	#contador para la imagen
	curl -s -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36' $url > enlace.txt
	price=$(cat enlace.txt | grep -oP "<span class=\"a-offscreen\">.*?</span>" | head -n1 | grep -oP '>.*?<' | tr -d '<>')
	old_price=$(cat enlace.txt | grep -oP "<span aria-hidden=\"true\">\d.*?€</span>" | grep -oP '>.*?<' | tr -d '<>' | head -n1)
	name=$(cat enlace.txt | grep -oP "<span id=\"productTitle\" class=\".*?\">.*?</span>" | grep -oP ">.*<" | tr -d '<>' | awk '{$1=$1}1')
	#image=$(cat enlace.txt | grep -o "data-old-hires=\".*jpg\"" | grep -oP "\".*?\"" | tr -d '"')
	image=$(cat enlace.txt | grep -oP '<img[^>]*\bsrc="\K[^"]+(?=".*id="landingImage")')
	#Exportarlas a otra ruta y cuando sea necesario actualizar la pagina, copiarlas a imagenes
	wget -q $image -O $num.jpg
#	echo $old_price
	mysql -u root -p110400 -e "use todochollos; UPDATE products SET name_products='$name', old_price_products='$old_price', price_products='$price', link_products='$url' WHERE id_products='$num';"
	let num++
done

