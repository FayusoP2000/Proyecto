#!/bin/bash

#Autor: Fernando Ayuso Perez
#Description:

#Colours
greenColor="\e[0;32m\033[1m"
endColor="\033[0m\e[0m"
redColor="\e[0;31m\033[1m"
blueColor="\e[0;34m\033[1m"
yellowColor="\e[0;33m\033[1m"
purpleColor="\e[0;35m\033[1m"
turquoiseColor="\e[0;36m\033[1m"
grayColor="\e[0;37m\033[1m"

#VARS
prompt=$(echo -e "\t${redColor}$(whoami)@$(hostnamectl | head -n1 | xargs |cut -d' ' -f3) #${endColor}  ${grayColor}$0 ${endColor}")
web="/var/www/html/a"

trap ctrl_c INT

function ctrl_c() {
	echo -e "\n\n\t${redColor}[*] Saliendo....${endColor}"
	tput cnorm
	exit 1
}

clear
echo -e "\t${purpleColor} _____          _         ___ _           _ _            ${endColor}"
echo -e "\t${purpleColor}/__   \___   __| | ___   / __\ |__   ___ | | | ___  ___  ${endColor}"
echo -e "\t${purpleColor}  / /\/ _ \ / _\` |/ _ \ / /  | '_ \ / _ \| | |/ _ \/ __| ${endColor}"
echo -e "\t${purpleColor} / / | (_) | (_| | (_) / /___| | | | (_) | | | (_) \__ \ ${endColor}"
echo -e "\t${purpleColor} \/   \___/ \__,_|\___/\____/|_| |_|\___/|_|_|\___/|___/ ${endColor}"

echo -e "\n"
echo -e "\t${turquoiseColor}Instrucciones de uso:${endColor}\n"
echo -e "\t\t${yellowColor}[*]${endColor} ${grayColor}$0 (opción)${endColor}\n"
echo -e "\t\t    ${purpleColor}1)${endColor}  ${grayColor}Recopilación de productos y almacenaje en la BBDD${endColor}"
echo -e "\t\t    ${purpleColor}2)${endColor}  ${grayColor}Actualización instantánea de la página${endColor}"
echo -e "\t\t    ${purpleColor}3)${endColor}  ${grayColor}Configurar rango de actualización de la página${endColor}"
echo -e "\t\t    ${purpleColor}4)${endColor}  ${grayColor}Configuración de backups${endColor}"
echo -e "\t\t    ${purpleColor}5)${endColor}  ${grayColor}Salir${endColor}\n"

read -p "$prompt" opcion

case $opcion in
	1)
	#script uno

	;;
	2)
	for num in $(seq 1 12)
	do
		name=$(mysql -s -u root -p110400 -e "use todochollos; select name_products from  products where id_products = $num" | grep -v '_products' | tr -d '!*[]}{⨪_.,="·#~%$')
		price=$(mysql -s -u root -p110400 -e "use todochollos; select price_products from  products where id_products = $num" | grep -v '_products')
		old_price=$(mysql -s -u root -p110400 -e "use todochollos; select old_price_products from  products where id_products = $num" | grep -v '_products')
		link=$(mysql -s -u root -p110400 -e "use todochollos; select link_products from  products where id_products = $num" | grep -v '_products')

		echo $name
#		sed -i "s/id=\"Parse name $num\">.*<\/h2>/id=\"Parse name $num\">$name<\/h2>/gi" $web/index.php
		sed -i "s/id=\"Parse price $num\">.*<\/p>/id=\"Parse price $num\">$price<\/p>/gi" $web/index.php
		sed -i "s/id=\"Parse old_price $num\">.*<\/del>/id=\"Parse old_price $num\">$old_price<\/del>/gi" $web/index.php
		sed -i "s/id=\"Parse link $num\" onclick=\"window.location.href='.*'\">/id=\"Parse link $num\" onclick=\"window.location.href='$link'\">/gi" $web/index.php
		cp -f /root/pruebas/$num.jpg $web/images
	done

	;;
	3)
	#fads
	;;
	4)

	;;
	5)
		echo -e "\n\t${redColor}[*]${endColor} ${redColor}Saliendo....${endColor}\n\n"
		exit
	;;
	*)
		echo -e "\t[!] No se ha seleccionado una opcion permitida. Saliendo ..."
		exit
esac
